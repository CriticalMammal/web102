jQuery(document).ready(function($) {

	











}); // end $(doc) ready